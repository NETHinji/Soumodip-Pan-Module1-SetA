﻿using System;
using System.Runtime.Serialization;

namespace GatePassApplication.GatePassExceptions
{
    
    public class GatePassException : Exception
    {
        public GatePassException()
        {
        }

        public GatePassException(string message) : base(message)
        {
        }

        public GatePassException(string message, Exception innerException) : base(message, innerException)
        {
        }

        
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorExample
{
    class Calculator
    {
        static void Main(string[] args)
        {
           
            try
            {
               
                Assembly assembly = Assembly.GetExecutingAssembly();
                Type t = assembly.GetType("CalculatorExample.abc");
                MethodInfo methodInfo = t.GetMethod("CalculateInterest", BindingFlags.Public | BindingFlags.Static);
                Console.WriteLine("Enter Principle");
                int p = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Interest");
                float i = Convert.ToSingle(Console.ReadLine());
                Console.WriteLine("Enter No Of Years");
                float n= Convert.ToSingle(Console.ReadLine());
               /* float result =*/ Convert.ToInt32(methodInfo.Invoke(null, new object[]{ p, i, n }));
               //Console.WriteLine(result);
               // Console.ReadKey();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
       
    }
}

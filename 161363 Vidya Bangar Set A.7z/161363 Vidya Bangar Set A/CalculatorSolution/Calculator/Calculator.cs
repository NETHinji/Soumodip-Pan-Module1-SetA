﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorExample
{
    public class abc
    {
        public static void CalculateInterest(int pri, float rate, float noOfYears)
        {
            float si = (pri * rate * noOfYears) / 100;
            //return si;
            Console.WriteLine("Simple Interest " + si);
        }
    }
}

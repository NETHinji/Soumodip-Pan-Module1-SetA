﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOLIDPrincipleValidImplementation
{
    // This example is violating Interface Segregation Principle of SOLID Principle 
    //Valid Implementation
    interface IUserLogin
    {
        bool Login(string username, string password);
        bool LogError(string error);
    }
}

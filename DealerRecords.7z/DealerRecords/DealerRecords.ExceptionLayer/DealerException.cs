﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace DealerRecords.ExceptionLayer
{
    [Serializable]
    public class DealerException:SystemException
    {
        
       
            public DealerException()
            {
            }

            public DealerException(string message) : base(message)
            {
            }

            public DealerException(string message, System.Exception innerException) : base(message, innerException)
            {
            }

            protected DealerException(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
    }


﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DealerRecords.BusinessLogicLayer;
using DealerRecords.EntityLayer;
using DealerRecords.ExceptionLayer;

namespace DealerRecords.PresentationLayer
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"D:\Users\\files\obj.dat";
            if (File.Exists(path))
                DealerBL.ReloadList(path);
            do
            {
                Console.WriteLine("Enter your Choice:");
                Menu();
                switch (Convert.ToInt32(Console.ReadLine()))
                {
                    case 1:
                        AddDealerDetails();
                        break;
                    case 2:
                        SearchDealerDetails();
                        break;
                    case 3:
                        DealerBL.SaveObject();
                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            } while (true);
        }

        private static void Menu()
        {
            Console.WriteLine("\n***********DealerDetails Management System Menu***********");
            Console.WriteLine("1. Add Dealer Details");
            Console.WriteLine("2. Search Dealer by Product Category");
            Console.WriteLine("3. Exit");
            Console.WriteLine("******************************************\n");
        }

        private static void AddDealerDetails()
        {
            try
            {
                Dealer temp = new Dealer();

                Console.WriteLine("Enter the Dealer ID");
                temp.DealerID = Console.ReadLine();

                Console.WriteLine("Enter the Dealer Name");
                temp.DealerName = Console.ReadLine();

                Console.WriteLine("Enter the Dealer Address");
                temp.DealerAddress = Console.ReadLine();

                Console.WriteLine("Enter the Dealer Product Category");
                temp.ProductCategory = Console.ReadLine();

                Console.WriteLine("Enter the Dealer Phone Number");
                temp.DealerPhoneNo = Convert.ToInt64(Console.ReadLine());

                Console.WriteLine("Enter the Dealer Email");
                temp.DealerEmailID = Console.ReadLine();

                if (DealerBL.AddDealerBL(temp))
                    Console.WriteLine("Dealer Deatails Added");
                else
                    Console.WriteLine("Dealer Details not Added");
            }
            catch (DealerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SearchDealerDetails()
        {
            try
            {
                Console.WriteLine("Enter the Product to be Search");
                string Product = Console.ReadLine();
                if (DealerBL.productList.Contains(Product))
                {
                    List<Dealer> temp = DealerBL.SearchDealerBL(Product);
                    if (temp != null)
                        foreach (Dealer dealer in temp)
                        {
                            Console.WriteLine("******************************************************************************");
                            Console.WriteLine("DealerID\t\tName\t\tAddress\t\tProduct\t\tContact\t\tEmail");
                            Console.WriteLine("******************************************************************************");
                            Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}", dealer.DealerID, dealer.DealerName, dealer.DealerAddress, dealer.ProductCategory, dealer.DealerPhoneNo, dealer.DealerEmailID);
                            Console.WriteLine("******************************************************************************");
                        }
                    else
                        Console.WriteLine("No such Dealer details available");
                }
            }
            catch (DealerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Exit()
        {
            try
            {
                DealerBL.SaveObject();
            }
            catch (DealerException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
    }

